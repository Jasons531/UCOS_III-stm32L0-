Concerning the app_cfg.h file.  The IAR and TrueStudio projects use their 
own version of the app_cfg.h file within their project folder and KeilMDK
uses the app_cfg.h file from the uCOS-III folder.